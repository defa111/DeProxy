# DhpLeProxy — Android VPN

DhpLeProxy is an Android VPN front-end using the Hev SOCKS5 TUN engine.

## Connection requirements
- A reachable SOCKS5 server with UDP Associate support
- TUN IPv4: `10.27.27.2/32`
- DNS resolvers: `1.1.1.1` and `8.8.8.8`
- Growtopia IPv4 route: `213.179.209.175/32` (verify the current game endpoint)

The app accepts a separately reachable SOCKS5 endpoint. A successful APK build only confirms that the project compiles and packages; a working VPN connection still requires a compatible SOCKS5 server.

## Build
Requires JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.9:

```sh
gradle --no-daemon :app:assembleDebug
```

The debug APK output is `app/build/outputs/apk/debug/app-debug.apk`.
