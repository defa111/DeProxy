# Third-party notices

This project bundles `libhev-socks5-tunnel.so` for arm64-v8a, armeabi-v7a,
and x86_64 from the user-provided SiProxy APK. The APK includes the corresponding
Hev, lwIP, and YAML license notices under `app/src/main/assets/licenses/native-vpn/`.
Those notices are retained in this project. The Hev tunnel project identifies
its license as MIT: https://github.com/heiher/hev-socks5-tunnel

No `libsiproxy.so`, SiProxy account/authentication code, API key, or proprietary
SiProxy UI/code is included.
