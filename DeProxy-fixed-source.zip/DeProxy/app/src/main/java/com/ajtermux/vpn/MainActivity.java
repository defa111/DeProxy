package com.ajtermux.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 701;
    private EditText hostInput, portInput, userInput, passInput, gameIpInput;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 8, 20));
        getWindow().setNavigationBarColor(Color.rgb(10, 8, 20));
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(28));
        root.setBackgroundColor(Color.rgb(10, 8, 20));
        scroll.addView(root);

        TextView brand = new TextView(this);
        brand.setText("✦ DhpLeProxy");
        brand.setTextColor(Color.rgb(190, 145, 255));
        brand.setTextSize(25);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("GROWTOPIA TUNNEL • PURPLE EDITION");
        subtitle.setTextColor(Color.rgb(166, 151, 190));
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(5), 0, dp(20));
        root.addView(subtitle);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.rgb(26, 18, 43));
        panelBg.setCornerRadius(dp(18));
        panel.setBackground(panelBg);
        root.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        addLabel(panel, "UPSTREAM SOCKS5");
        hostInput = addInput(panel, "IP SOCKS5 (contoh 127.0.0.1)", InputType.TYPE_CLASS_TEXT);
        portInput = addInput(panel, "Port (contoh 1080)", InputType.TYPE_CLASS_NUMBER);
        userInput = addInput(panel, "Username (opsional)", InputType.TYPE_CLASS_TEXT);
        passInput = addInput(panel, "Password (opsional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        addLabel(panel, "GROWTOPIA GAME SERVER IPv4");
        gameIpInput = addInput(panel, "213.179.209.175", InputType.TYPE_CLASS_TEXT);
        gameIpInput.setText("213.179.209.175");

        TextView dns = new TextView(this);
        dns.setText("DNS: 1.1.1.1  •  8.8.8.8\nTUN: 10.27.27.2/32\nMode: hanya IP game + trafik DNS yang diarahkan ke tunnel.");
        dns.setTextColor(Color.rgb(190, 178, 211));
        dns.setTextSize(12);
        dns.setPadding(0, dp(12), 0, dp(6));
        panel.addView(dns);

        TextView warning = new TextView(this);
        warning.setText("Catatan: server SOCKS5 wajib mendukung UDP Associate. Pastikan alamat server dan port yang digunakan benar serta dapat dijangkau.");
        warning.setTextColor(Color.rgb(211, 177, 255));
        warning.setTextSize(12);
        warning.setPadding(0, dp(8), 0, dp(14));
        panel.addView(warning);

        Button connect = button("CONNECT", Color.rgb(126, 75, 210));
        panel.addView(connect, matchWrap());
        connect.setOnClickListener(v -> requestVpn());

        Button disconnect = button("DISCONNECT", Color.rgb(65, 49, 88));
        LinearLayout.LayoutParams stopLp = matchWrap();
        stopLp.topMargin = dp(9);
        panel.addView(disconnect, stopLp);
        disconnect.setOnClickListener(v -> {
            Intent i = new Intent(this, AJTermuxVpnService.class);
            i.setAction(AJTermuxVpnService.ACTION_STOP);
            startService(i);
            Toast.makeText(this, "Permintaan disconnect dikirim", Toast.LENGTH_SHORT).show();
        });

        TextView foot = new TextView(this);
        foot.setText("DhpLeProxy • Growtopia tunnel");
        foot.setTextColor(Color.rgb(130, 112, 157));
        foot.setTextSize(11);
        foot.setPadding(dp(2), dp(18), dp(2), 0);
        root.addView(foot);
        setContentView(scroll);
    }

    private void requestVpn() {
        String host = hostInput.getText().toString().trim();
        String port = portInput.getText().toString().trim();
        String gameIp = gameIpInput.getText().toString().trim();
        if (host.isEmpty() || port.isEmpty()) {
            toast("Isi alamat dan port SOCKS5 dulu"); return;
        }
        int p;
        try { p = Integer.parseInt(port); } catch (Exception e) { toast("Port tidak valid"); return; }
        if (p < 1 || p > 65535) { toast("Port harus 1-65535"); return; }
        if (!isIpv4(gameIp)) { toast("IP server game harus IPv4"); return; }
        if (host.contains(" ") || host.contains("\n") || host.contains("\r")) { toast("Host SOCKS5 tidak valid"); return; }

        getSharedPreferences(AJTermuxVpnService.PREFS, MODE_PRIVATE).edit()
                .putString("socks_host", host)
                .putInt("socks_port", p)
                .putString("socks_user", userInput.getText().toString())
                .putString("socks_pass", passInput.getText().toString())
                .putString("game_ip", gameIp)
                .apply();

        Intent prepare = VpnService.prepare(this);
        if (prepare != null) startActivityForResult(prepare, VPN_REQUEST);
        else launchVpnService();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST) {
            if (resultCode == RESULT_OK) launchVpnService();
            else toast("Izin VPN tidak diberikan");
        }
    }

    private void launchVpnService() {
        Intent i = new Intent(this, AJTermuxVpnService.class);
        i.setAction(AJTermuxVpnService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        toast("Memulai tunnel...");
    }

    private boolean isIpv4(String value) {
        String[] parts = value.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            try { if (part.isEmpty() || part.length() > 3) return false; int n = Integer.parseInt(part); if (n < 0 || n > 255) return false; }
            catch (Exception e) { return false; }
        }
        return true;
    }

    private void addLabel(LinearLayout parent, String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.rgb(190, 145, 255));
        t.setTextSize(11); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(0, dp(8), 0, dp(7)); parent.addView(t);
    }

    private EditText addInput(LinearLayout parent, String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(143, 126, 168)); e.setTextSize(14); e.setInputType(type);
        e.setPadding(dp(12), dp(9), dp(12), dp(9));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(14, 10, 25)); bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(103, 76, 142)); e.setBackground(bg);
        LinearLayout.LayoutParams lp = matchWrap(); lp.bottomMargin = dp(8); parent.addView(e, lp); return e;
    }

    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(color); bg.setCornerRadius(dp(12)); b.setBackground(bg); return b;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
