# DeProxy — Android VPN prototype

DeProxy is an Android `VpnService` front-end using the Hev SOCKS5 TUN engine. It is an independent prototype, not a copy/unlocker of SiProxy.

## Initial profile
- TUN IPv4: `10.27.27.2/32`
- DNS resolvers: `1.1.1.1` and `8.8.8.8`
- Growtopia IPv4 route: `213.179.209.175/32` (verify against the current game endpoint)
- SOCKS5 UDP relay: required

## Important compatibility boundary
The AJTermux installer downloads and runs a native `proxy` executable. Its published `vars` endpoint (`195.62.48.50:1234`) is not proof that it exposes a SOCKS5 server. DeProxy currently accepts a separately reachable SOCKS5 endpoint; it does not start AJTermux's binary inside the APK. For Growtopia, that SOCKS5 server must support UDP Associate. Do not assume the AJTermux endpoint is compatible until tested.

DNS values are public resolvers seen in the inspected SiProxy VPN profile; they are not private SiProxy credentials or a guarantee of equivalent routing.

## Build locally
Requires JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.9:

```sh
gradle --no-daemon :app:assembleDebug
```

The debug APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Build with GitHub Actions
The included workflow is `.github/workflows/build-apk.yml`. Push this project to the `main` or `master` branch, or run it manually from the repository's **Actions** tab. When the job succeeds, download the `DeProxy-debug-apk` artifact from the completed workflow run.

The workflow uses JDK 17, Android command-line tools 22.0, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.9. It avoids the older Android SDK setup action version used by the previous failing workflow.

## Compatibility note
A successful APK build only confirms that the project compiles and packages. A working VPN connection still requires a reachable SOCKS5 server that supports UDP Associate; the app does not automatically turn the AJTermux `vars` endpoint into a SOCKS5 server.
