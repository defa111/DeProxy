package com.ajtermux.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ServiceInfo;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.IBinder;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

import hev.htproxy.TProxyService;

public class AJTermuxVpnService extends VpnService {
    public static final String ACTION_START = "com.ajtermux.vpn.START";
    public static final String ACTION_STOP = "com.ajtermux.vpn.STOP";
    public static final String PREFS = "ajt_vpn_prefs";
    private static final String CHANNEL = "ajt_vpn_channel";
    private static final int NOTIFICATION_ID = 41;
    private static final String TUN_IP = "10.27.27.2";
    private static final String DNS1 = "1.1.1.1";
    private static final String DNS2 = "8.8.8.8";

    private ParcelFileDescriptor tun;
    private boolean nativeStarted;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopTunnel();
            stopForegroundCompat();
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundCompat(makeNotification("Menyiapkan tunnel Growtopia"));
        try {
            startTunnel();
            updateNotification("VPN aktif • Growtopia route");
        } catch (Throwable error) {
            stopTunnel();
            updateNotification("Gagal: " + safeMessage(error));
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startTunnel() throws Exception {
        stopTunnel();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String host = prefs.getString("socks_host", "").trim();
        int port = prefs.getInt("socks_port", 0);
        String username = prefs.getString("socks_user", "");
        String password = prefs.getString("socks_pass", "");
        String gameIp = prefs.getString("game_ip", "213.179.209.175");
        if (host.isEmpty() || port < 1 || port > 65535) throw new IllegalArgumentException("Alamat SOCKS5/port belum benar");

        Builder builder = new Builder();
        builder.setSession("DeProxy");
        builder.setMtu(1500);
        builder.addAddress(TUN_IP, 32);
        builder.addDnsServer(DNS1);
        builder.addDnsServer(DNS2);
        // Only the Growtopia IPv4 endpoint and the two configured DNS resolvers enter the tunnel.
        builder.addRoute(gameIp, 32);
        builder.addRoute(DNS1, 32);
        builder.addRoute(DNS2, 32);
        tun = builder.establish();
        if (tun == null) throw new IllegalStateException("Android tidak memberikan antarmuka TUN");

        File config = new File(getFilesDir(), "hev-socks5-tunnel.yaml");
        String yaml = makeYaml(host, port, username, password);
        try (FileOutputStream out = new FileOutputStream(config, false)) {
            out.write(yaml.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }

        nativeStarted = TProxyService.TProxyStartService(config.getAbsolutePath(), tun.getFd());
        if (!nativeStarted) throw new IllegalStateException("Mesin tunnel menolak konfigurasi. Pastikan server SOCKS5 aktif dan mendukung UDP Associate.");
    }

    private String makeYaml(String host, int port, String username, String password) {
        StringBuilder y = new StringBuilder();
        y.append("tunnel:\n");
        y.append("  mtu: 1500\n");
        y.append("  ipv4: ").append(TUN_IP).append("\n");
        y.append("socks5:\n");
        y.append("  address: ").append(yamlQuote(host)).append("\n");
        y.append("  port: ").append(port).append("\n");
        y.append("  udp: 'udp'\n");
        if (!username.isEmpty() || !password.isEmpty()) {
            y.append("  username: ").append(yamlQuote(username)).append("\n");
            y.append("  password: ").append(yamlQuote(password)).append("\n");
        }
        y.append("misc:\n");
        y.append("  tcp-read-write-timeout: 300000\n");
        y.append("  udp-read-write-timeout: 60000\n");
        y.append("  log-level: warn\n");
        return y.toString();
    }

    private String yamlQuote(String value) {
        return "'" + value.replace("'", "''").replace("\r", "").replace("\n", "") + "'";
    }

    private void stopTunnel() {
        if (nativeStarted) {
            try { TProxyService.TProxyStopService(); } catch (Throwable ignored) { }
            nativeStarted = false;
        }
        if (tun != null) {
            try { tun.close(); } catch (Exception ignored) { }
            tun = null;
        }
    }

    @Override public void onRevoke() {
        stopTunnel();
        stopForegroundCompat();
        stopSelf();
        super.onRevoke();
    }

    @Override public void onDestroy() {
        stopTunnel();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return super.onBind(intent); }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "DeProxy", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Status koneksi tunnel Growtopia");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private Notification makeNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, AJTermuxVpnService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_sys_upload_done)
                .setContentTitle("DeProxy")
                .setContentText(text)
                .setContentIntent(content)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Disconnect", stopPi);
        return b.build();
    }

    private void startForegroundCompat(Notification n) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIFICATION_ID, n);
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, makeNotification(text));
    }

    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
    }

    private String safeMessage(Throwable t) {
        String m = t.getMessage();
        return m == null ? t.getClass().getSimpleName() : m;
    }
}
