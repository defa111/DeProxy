# DeProxy — build workflow fix

This package fixes the known GitHub Actions failure in the current DeProxy workflow.

## What failed

The 4 November 2026 run successfully checked out the repository, extracted `DeProxy-fixed-source.zip`, and installed Java 17. It then failed in `Setup Android SDK` because `android-actions/setup-android@v3` tried to install the retired SDK package `tools`; `sdkmanager` returned `Failed to find package 'tools'`.

## Apply the fix

1. Open the repository: https://github.com/defa111/DeProxy
2. Replace `.github/workflows/build-apk.yml` with the file at `.github/workflows/build-apk.yml` in this package.
3. Commit the change to `main`.
4. Open the repository's **Actions** tab and open the newest **Build DeProxy APK** run.
5. If it succeeds, download the artifact named `DeProxy-debug-apk` and install `app-debug.apk` on Android.

The change upgrades the Android setup action to v4 and explicitly requests only `platform-tools`, avoiding the removed `tools` package. The workflow still installs Android 35 and Build Tools 35.0.0 before building.

## Important scope

This package is a CI/build fix, **not a compiled APK**. It only fixes the first failure seen in the current Actions log. A later Gradle or source-code error, if one appears, will need its own diagnosis.
