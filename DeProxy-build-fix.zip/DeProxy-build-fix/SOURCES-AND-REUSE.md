# Source reuse notes for the planned low-cost proxy

- **GTProxy (ZTzTopia):** The repository README declares MIT licensing and describes an open-source Growtopia packet proxy. Its documented build uses CMake, C++23, and Conan. The README lists Windows, GNU/Linux, and macOS as tested platforms, not Android. Treat it as the packet/network core reference and preserve its MIT license/attribution when code is reused.
- **AJTermux:** The inspected repository contains an installer that downloads a prebuilt `proxy` binary, plus a `vars` configuration file. It is not a source-code kit. The configuration includes third-party server endpoints and webhook-like secrets, so none of those should be copied into DeProxy.
- **SiProxy:** The public repository inspected contains an APK and a tiny host mapping file, not the Android application source. The previously supplied APK string dump is not a decompilation or complete source tree. Its authentication configuration, private certificate material, and server-side key checks should not be copied or bypassed.

## Cost and architecture target

For a Rp5,000 budget, start with **local-only operation on the Android phone**. Do not rent a VPS or buy a domain. Use an Android `VpnService`/local tunnel layer for device traffic, and a separately audited packet-processing core inspired by GTProxy's licensed components. Keep game account authentication on the official Growtopia endpoints; do not promise ban avoidance or anti-cheat bypass.

A real Android port is still a separate engineering task: GTProxy's documented C++23/Conan build is not documented as Android-supported. Do not advertise this workflow patch as a working port until the APK has built and been tested on the target phone.
